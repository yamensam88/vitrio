"use client";

import { createContext, useContext, useState, ReactNode } from 'react';


// Types
export interface Appointment {
    id: number;
    clientName: string;
    vehicle: string;
    date: string; // ISO String
    status: "En attente" | "Confirmé" | "Terminé";
    amount: number;
    garageId: string; // To link to a specific garage (mock: we'll mostly use the current garage context)
    offers: string[];
}

export interface AdminGarage {
    id: number;
    name: string;
    city: string;
    status: "En attente" | "Actif" | "Suspendu";
    registrationDate: string;
}

interface AppContextType {
    appointments: Appointment[];
    addAppointment: (app: Omit<Appointment, 'id' | 'status'>) => void;
    updateAppointmentStatus: (id: number, status: Appointment['status']) => void;

    adminGarages: AdminGarage[];
    updateGarageStatus: (id: number, status: AdminGarage['status']) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
    // --- Appointments State (Shared between Client & Partner) ---
    const [appointments, setAppointments] = useState<Appointment[]>([
        { id: 1, clientName: "Jean D.", vehicle: "Peugeot 208", date: "2024-05-20T14:00:00.000Z", status: "Confirmé", amount: 120, garageId: "g1", offers: ["Remplacement Standard"] },
        { id: 2, clientName: "Sophie M.", vehicle: "Renault Clio IV", date: "2024-05-21T09:30:00.000Z", status: "En attente", amount: 150, garageId: "g1", offers: ["Premium + Nettoyage"] },
    ]);

    const addAppointment = (app: Omit<Appointment, 'id' | 'status'>) => {
        const newApp: Appointment = {
            ...app,
            id: Math.max(0, ...appointments.map(a => a.id)) + 1,
            status: "En attente"
        };
        setAppointments(prev => [newApp, ...prev]);
    };

    const updateAppointmentStatus = (id: number, status: Appointment['status']) => {
        setAppointments(prev => prev.map(a => a.id === id ? { ...a, status } : a));
    };

    // --- Admin Garages State ---
    const [adminGarages, setAdminGarages] = useState<AdminGarage[]>([
        { id: 1, name: "AutoGlass Paris 12", city: "Paris", status: "Actif", registrationDate: "2024-01-15" },
        { id: 2, name: "Rapid Pare-Brise Lyon", city: "Lyon", status: "En attente", registrationDate: "2025-12-12" },
        { id: 3, name: "Marseille Vitrage", city: "Marseille", status: "Suspendu", registrationDate: "2023-11-20" },
        { id: 4, name: "Bordeaux Glass", city: "Bordeaux", status: "En attente", registrationDate: "2025-12-13" },
    ]);

    const updateGarageStatus = (id: number, status: AdminGarage['status']) => {
        setAdminGarages(prev => prev.map(g => g.id === id ? { ...g, status } : g));
    };

    return (
        <AppContext.Provider value={{
            appointments,
            addAppointment,
            updateAppointmentStatus,
            adminGarages,
            updateGarageStatus
        }}>
            {children}
        </AppContext.Provider>
    );
}

export function useApp() {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useApp must be used within an AppProvider');
    }
    return context;
}
