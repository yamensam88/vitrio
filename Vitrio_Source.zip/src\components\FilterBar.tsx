import { SortOption } from "@/hooks/useGarageSearch";

interface FilterBarProps {
    currentSort: SortOption;
    onSortChange: (sort: SortOption) => void;
    disabled?: boolean;
}

export const FilterBar = ({ currentSort, onSortChange, disabled }: FilterBarProps) => {
    const options: { value: SortOption; label: string; icon: string }[] = [
        { value: "distance", label: "Proximité", icon: "📍" },
        { value: "price", label: "Meilleure Offre", icon: "💰" },
        { value: "availability", label: "Rdv Rapide", icon: "⚡️" },
    ];

    return (
        <div style={{
            display: 'flex',
            gap: '0.75rem',
            overflowX: 'auto',
            paddingBottom: '0.5rem',
            scrollbarWidth: 'none'
        }}>
            {options.map((opt) => (
                <button
                    key={opt.value}
                    onClick={() => onSortChange(opt.value)}
                    disabled={disabled}
                    style={{
                        padding: '0.6rem 1.25rem',
                        borderRadius: 'var(--radius-full)',
                        border: '1px solid',
                        borderColor: currentSort === opt.value ? 'var(--color-primary)' : '#E2E8F0',
                        backgroundColor: currentSort === opt.value ? 'var(--color-primary)' : 'white',
                        color: currentSort === opt.value ? 'white' : 'var(--color-text-secondary)',
                        cursor: disabled ? 'not-allowed' : 'pointer',
                        opacity: disabled ? 0.6 : 1,
                        whiteSpace: 'nowrap',
                        fontSize: '0.9rem',
                        fontWeight: 600,
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        transition: 'all 0.2s',
                        boxShadow: currentSort === opt.value ? '0 4px 6px -1px rgba(0, 119, 255, 0.2)' : 'none'
                    }}
                >
                    <span>{opt.icon}</span>
                    {opt.label}
                </button>
            ))}
        </div>
    );
};
