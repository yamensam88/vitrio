import { useState, useMemo } from "react";
import { Coordinates } from "@/types";
import { GeolocationService } from "@/services/GeolocationService";
import { MOCK_GARAGES } from "@/data/garages";

export type SortOption = "distance" | "price" | "availability";

export const useGarageSearch = () => {
    const [userLocation, setUserLocation] = useState<Coordinates | null>(null);
    const [sortBy, setSortBy] = useState<SortOption>("distance");
    const [loadingLocation, setLoadingLocation] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Function to trigger geolocation
    const locateUser = async () => {
        setLoadingLocation(true);
        setError(null);
        try {
            const location = await GeolocationService.getUserLocation();
            setUserLocation(location);
            setSortBy("distance"); // Default to distance when location is found
        } catch (err) {
            console.error(err);
            setError("Impossible de vous géolocaliser. Vérifiez vos paramètres.");
        } finally {
            setLoadingLocation(false);
        }
    };

    // Main logic to process garages
    const processedGarages = useMemo(() => {
        const results = MOCK_GARAGES.map((garage) => {
            // Calculate distance if location is available
            let distance = undefined;
            if (userLocation) {
                distance = GeolocationService.calculateDistance(
                    userLocation,
                    garage.coordinates
                );
            }
            return { ...garage, distance };
        });

        // Sorting Logic
        results.sort((a, b) => {
            if (sortBy === "distance") {
                if (a.distance === undefined) return 1; // Put unknown distance last
                if (b.distance === undefined) return -1;
                return a.distance - b.distance;
            }

            if (sortBy === "price") {
                // Find cheapest offer for each garage
                const priceA = Math.min(...a.offers.map((o) => o.price));
                const priceB = Math.min(...b.offers.map((o) => o.price));
                return priceA - priceB;
            }

            if (sortBy === "availability") {
                return (
                    new Date(a.nextAvailability).getTime() -
                    new Date(b.nextAvailability).getTime()
                );
            }

            return 0;
        });

        return results;
    }, [userLocation, sortBy]);

    return {
        garages: processedGarages,
        userLocation,
        loadingLocation,
        locateUser,
        sortBy,
        setSortBy,
        error,
    };
};
